<template>
  <div>
    <h2>拖动四个角均可实现拖拽放大</h2>
    <div class="box">
      <div id="se-block"><!-- 越右下越大 --></div>
      <div id="ne-block"><!-- 越右上越大 --></div>
      <div id="nw-block"><!-- 越左上越大 --></div>
      <div id="sw-block"><!-- 越左下越大 --></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "dragToBig",
  data() {
    return {};
  },
  mounted() {
    var box = document.getElementsByClassName("box")[0];
    var seBlock = document.getElementById("se-block");
    var neBlock = document.getElementById("ne-block");
    var nwBlock = document.getElementById("nw-block");
    var swBlock = document.getElementById("sw-block");

    /**
     * --拖拽放大
     * 注意点：以目标元素大块高宽所在方位为正x,y
     * 本质：确定鼠标初始偏移，之后再大的尺寸加在目标元素高宽上
     */

    // sw左下角
    // onmousedown鼠标按下
    swBlock.onmousedown = function (ev) {
      var myEvent = ev || window.event;
      var distanceX =
        window.innerWidth -
        myEvent.clientX -
        (box.offsetWidth - swBlock.offsetWidth);
      var distanceY = myEvent.clientY - swBlock.offsetTop;

      // onmousemove鼠标移动
      document.onmousemove = function (ev) {
        var myEvent = ev || window.event;
        box.style.width =
          window.innerWidth -
          myEvent.clientX -
          distanceX +
          swBlock.offsetWidth +
          "px";
        box.style.height =
          myEvent.clientY - distanceY + swBlock.offsetHeight + "px";
      };
      // onmouseup清除鼠标按下起来后的事件执行
      document.onmouseup = function () {
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };

    // nw左上角
    // onmousedown鼠标按下
    nwBlock.onmousedown = function (ev) {
      var myEvent = ev || window.event;
      var distanceX =
        window.innerWidth -
        myEvent.clientX -
        (box.offsetWidth - nwBlock.offsetWidth);
      var distanceY =
        window.innerHeight -
        myEvent.clientY -
        (box.offsetHeight - nwBlock.offsetHeight);

      // onmousemove鼠标移动
      document.onmousemove = function (ev) {
        var myEvent = ev || window.event;
        box.style.width =
          window.innerWidth -
          myEvent.clientX -
          distanceX +
          nwBlock.offsetWidth +
          "px";
        box.style.height =
          window.innerHeight -
          myEvent.clientY -
          distanceY +
          nwBlock.offsetHeight +
          "px";
      };
      // onmouseup清除鼠标按下起来后的事件执行
      document.onmouseup = function () {
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };

    // ne右上角
    // onmousedown鼠标按下
    neBlock.onmousedown = function (ev) {
      var myEvent = ev || window.event;
      var distanceX = myEvent.clientX - neBlock.offsetLeft;
      var distanceY =
        window.innerHeight -
        myEvent.clientY -
        (box.offsetHeight - neBlock.offsetHeight);

      // onmousemove鼠标移动
      document.onmousemove = function (ev) {
        var myEvent = ev || window.event;
        box.style.width =
          myEvent.clientX - distanceX + neBlock.offsetWidth + "px";
        box.style.height =
          window.innerHeight -
          myEvent.clientY -
          distanceY +
          neBlock.offsetHeight +
          "px";
      };
      // onmouseup清除鼠标按下起来后的事件执行
      document.onmouseup = function () {
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };

    // se右下角
    // onmousedown鼠标按下
    seBlock.onmousedown = function (ev) {
      var myEvent = ev || window.event; // 捕获鼠标按下这个事件
      // clientX当事件被触发时鼠标指针相对于浏览器页面(客户区)的水平坐标
      // offsetLeft返回离最近的父辈中定位元素左边缘的距离
      var distanceX = myEvent.clientX - seBlock.offsetLeft;
      var distanceY = myEvent.clientY - seBlock.offsetTop;

      // onmousemove鼠标移动
      document.onmousemove = function (ev) {
        var myEvent = ev || window.event;
        // box.style.width改变box盒子的宽
        // offsetWidth是content+padding+border的宽度
        // clientWidth是content+padding的宽度
        // 鼠标移动的时候未改变distanceX的值，所以不变
        box.style.width =
          myEvent.clientX - distanceX + seBlock.offsetWidth + "px";
        box.style.height =
          myEvent.clientY - distanceY + seBlock.offsetHeight + "px";
      };

      // onmouseup清除鼠标按下起来后的事件执行
      document.onmouseup = function () {
        // 当鼠标的按键松开后，清除onmousemove事件，即不再拖拽放大
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };
  },
};
</script>

<style lang="less" scoped>
/* css */
* {
  padding: 0;
  margin: 0;
  /* box-sizing: border-box; */
}

.box {
  position: relative;
  margin: 30px auto;
  width: 300px;
  height: 200px;
  border: 1px solid goldenrod;
  background-color: green;
}

/* 属性选择器 $以之结尾 *含之 */
div[id$="block"] {
  position: absolute;
  /* display: none; */
  /* visibility: hidden; */
  width: 20px;
  height: 20px;
  background-color: transparent;
}

#se-block {
  bottom: 0;
  right: 0;
  cursor: se-resize;
}

#ne-block {
  top: 0;
  right: 0;
  cursor: ne-resize;
}

#nw-block {
  top: 0;
  left: 0;
  cursor: nw-resize;
}

#sw-block {
  bottom: 0;
  left: 0;
  cursor: sw-resize;
}
</style>
