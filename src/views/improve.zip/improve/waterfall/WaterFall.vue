<template>
  <div>

  </div>
</template>

<script>
export default {
  name: 'water-fall',
  data () {
    return {
      
    }
  },
  methods: {
       
  },
}
</script>

<style lang='less' scoped>

</style>
