# 各文件说明

`vue文件不用管，以下解释为html文件`

## carousel
 carousel_x_flat: 平面轮播图
 carousel_x_focus: 中心聚焦轮播图

## drag 
drag: 矩形四角拖拽放大

## timeline
timeline_x: 横向步骤条

## waterfall
waterfall_x: 横向瀑布流
waterfall_y: 纵向瀑布流